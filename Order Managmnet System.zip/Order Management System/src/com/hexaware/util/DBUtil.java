package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

    
    private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/ordermanagementsystem";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "uday@1830";

    // Prevent instantiation of the class
    private DBUtil() {
    }

    // Establish a connection to the database and return the Connection object
    public static Connection getDBConn() throws SQLException {
        try {
            // Load the MySQL JDBC driver
            Class.forName(JDBC_DRIVER);
            printDriverInfo();
        } catch (ClassNotFoundException e) {
            e.printStackTrace(); // Handle the exception according to your application's requirements
        }

        return DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
    }

    // Print information about the loaded JDBC driver
    private static void printDriverInfo() {
        System.out.println("JDBC driver loaded: " + JDBC_DRIVER);
    }
}
