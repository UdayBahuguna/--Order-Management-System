package com.hexaware.dao;
import com.hexaware.entity.User;
import com.hexaware.entity.Product;
import com.hexaware.exception.OrderNotFoundException;
import com.hexaware.exception.UserNotFoundException;
import java.util.List;

//Interface representing the Order Management Repository
public interface IOrderManagementRepository {

 // Method to create an order for a user with a list of products
 void createOrder(User user, List<Product> products);

 // Method to cancel an order based on userId and orderId
 void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException;

 // Method to create a product for an admin user
 void createProduct(User adminUser, Product product) throws UserNotFoundException;

 // Method to create a user and store in the database
 void createUser(User user);

 // Method to get all products from the database
 List<Product> getAllProducts();

 // Method to get all products ordered by a specific user from the database
 List<Product> getOrderByUser(User user);
 
 boolean isUserExistInDatabase(int userId);

 boolean isOrderExistInDatabase(int userId, int orderId);
}

